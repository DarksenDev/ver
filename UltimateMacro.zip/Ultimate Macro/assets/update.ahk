﻿#Requires AutoHotkey v1.1
#NoEnv
#SingleInstance, force

VERSION_URL := "https://raw.githubusercontent.com/DarksenDev/ver/refs/heads/main/information.ini"
SCRIPT_DIR := A_ScriptDir
TEMP_DIR := A_Temp "\TDSMacroUpdate"

if (%0% >= 2) {
    currentVersion = %1%
    SCRIPT_DIR = %2%
    result := CheckForUpdate(currentVersion)
    ExitApp %result%
} else {
    MsgBox, 16, Error, Usage: update.ahk <current_version> <script_dir>
    ExitApp 0
}

CheckForUpdate(currentVersion) {
    global VERSION_URL, SCRIPT_DIR, TEMP_DIR
    
    versionInfo := DownloadToString(VERSION_URL)
    if (!versionInfo) {
        ShowError("Failed to check for updates. Check your internet connection.")
        return 0
    }
    
    latestVersion := IniReadFromString(versionInfo, "VersionInfo", "latest_version", "")
    updateLog := IniReadFromString(versionInfo, "VersionInfo", "update_log", "")
    downloadURL := IniReadFromString(versionInfo, "VersionInfo", "download_url", "")
    
    if (latestVersion = "") {
        ShowError("Failed to parse version information.")
        return 0
    }
    
    currentVer := CleanVersion(currentVersion)
    latestVer := CleanVersion(latestVersion)
    
    if (currentVer = latestVer) {
        return 0 
    }
    
    updateMsg := "A new version is available: " latestVersion "`n"
    updateMsg .= "Your version: " currentVersion "`n`n"
    updateMsg .= "Changelog:`n" updateLog "`n`n"
    updateMsg .= "Update now?"
    
    MsgBox, 52, TDS Update, %updateMsg%
    IfMsgBox, No
        return 0
        
    Process, Close, TDSMacro.exe
    Process, Close, Ultimate Macro.exe
    Sleep, 500
    
    if (!DownloadAndInstall(downloadURL)) {
        ShowError("Failed to download or install the update.")
        return 0
    }
    
    MsgBox, 64, Update Successful, Update installed successfully!`nThe program will now restart.
    return 2 
}

DownloadToString(url) {
    try {
        whr := ComObjCreate("WinHttp.WinHttpRequest.5.1")
        whr.Open("GET", url, false) 
        whr.Send()
        return whr.ResponseText
    } catch e {
        return ""
    }
}

IniReadFromString(string, section, key, default := "") {
    tempFile := A_Temp "\tds_update_temp.ini"
    FileDelete, %tempFile%
    FileAppend, %string%, %tempFile%
    
    IniRead, value, %tempFile%, %section%, %key%, %default%
    FileDelete, %tempFile%
    return value
}

CleanVersion(ver) {
    ver := Trim(ver)
    ver := RegExReplace(ver, "^v|^V", "") 
    return ver
}

DownloadAndInstall(url) {
    global SCRIPT_DIR, TEMP_DIR
    
    FileRemoveDir, %TEMP_DIR%, 1
    FileCreateDir, %TEMP_DIR%
    
    zipPath := TEMP_DIR "\update.zip"
    extractPath := TEMP_DIR "\extracted"
    FileCreateDir, %extractPath%
    
    try {
        whr := ComObjCreate("WinHttp.WinHttpRequest.5.1")
        whr.Open("GET", url, false)
        whr.Send()
        
        if (whr.Status != 200)
            return false
            
        ado := ComObjCreate("ADODB.Stream")
        ado.Type := 1 
        ado.Open()
        ado.Write(whr.ResponseBody)
        ado.SaveToFile(zipPath, 2) 
        ado.Close()
    } catch e {
        return false
    }
    
    FileGetSize, zipSize, %zipPath%
    if (!FileExist(zipPath) || zipSize = 0) {
        return false
    }
    
    try {
        sh := ComObjCreate("Shell.Application")
        dst := sh.NameSpace(extractPath)
        src := sh.NameSpace(zipPath)
        dst.CopyHere(src.Items, 16 + 256) 
    } catch e {
        return false
    }
    
    sourcePath := extractPath "\TDSMacro"
    if (!FileExist(sourcePath)) {
        sourcePath := extractPath "\Ultimate Macro"
        if (!FileExist(sourcePath)) {
            sourcePath := extractPath 
        }
    }
    
    filesMoved := 0
    Loop, Files, %sourcePath%\*, DF R
    {
        StringReplace, relativePath, A_LoopFileFullPath, %sourcePath%\
        targetFile := SCRIPT_DIR "\" relativePath
        
        if (InStr(A_LoopFileAttrib, "D")) {
            FileCreateDir, %targetFile%
        } else {
            SplitPath, targetFile, , targetDir
            if (!FileExist(targetDir)) {
                FileCreateDir, %targetDir%
            }
            FileCopy, %A_LoopFileFullPath%, %targetFile%, 1 
            if (!ErrorLevel) {
                filesMoved++
            }
        }
    }
    
    FileRemoveDir, %TEMP_DIR%, 1
    
    if (filesMoved = 0) {
        return false
    }
    
    return true
}

ShowError(msg) {
    MsgBox, 16, Update Error, %msg%, 60
}
