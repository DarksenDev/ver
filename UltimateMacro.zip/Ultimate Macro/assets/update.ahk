﻿#Requires AutoHotkey v1.1
#NoEnv
#SingleInstance, force

VERSION_URL := "https://raw.githubusercontent.com/DarksenDev/ver/refs/heads/main/information.ini"
SCRIPT_DIR := A_ScriptDir
TEMP_DIR := A_Temp "\UltimateMacroUpdate"

CheckForUpdate(currentVersion) {
    global VERSION_URL, SCRIPT_DIR, TEMP_DIR

    versionInfo := DownloadToString(VERSION_URL)
    if (!versionInfo) {
        ShowError("Failed to check for updates. Check your internet connection.")
        return 0
    }
    
    latestVersion := IniReadFromString(versionInfo, "VersionInfo", "latest_version", "")
    updateLog := IniReadFromString(versionInfo, "VersionInfo", "update_log", "")
    downloadURL := IniReadFromString(versionInfo, "VersionInfo", "download_url", "")
    
    if (latestVersion = "") {
        ShowError("Failed to parse version information.")
        return 0
    }
    
    currentVer := CleanVersion(currentVersion)
    latestVer := CleanVersion(latestVersion)
    
    if (currentVer = latestVer) {
        return 0 
    }
    
    updateMsg := "A new version is available: " latestVersion "`n"
    updateMsg .= "Your version: " currentVersion "`n`n"
    updateMsg .= "Changelog:`n" updateLog "`n`n"
    updateMsg .= "Update now?"
    
    MsgBox, 52, Ultimate Macro Update, %updateMsg%
    IfMsgBox, No
        return 0
    
    if (!DownloadAndInstall(downloadURL)) {
        ShowError("Failed to download or install the update.")
        return 0
    }
    
    MsgBox, 64, Update Successful, Update installed successfully!`nThe program will now restart.
    return 2 
}

DownloadToString(url) {
    try {
        whr := ComObjCreate("WinHttp.WinHttpRequest.5.1")
        whr.Open("GET", url, true)
        whr.Send()
        whr.WaitForResponse()
        return whr.ResponseText
    } catch e {
        return ""
    }
}

IniReadFromString(string, section, key, default := "") {
    tempFile := A_Temp "\um_update_temp.ini"
    FileDelete, %tempFile%
    FileAppend, %string%, %tempFile%
    
    IniRead, value, %tempFile%, %section%, %key%, %default%
    FileDelete, %tempFile%
    return value
}

CleanVersion(ver) {
    ver := Trim(ver)
    ver := RegExReplace(ver, "^v|^V", "") 
    return ver
}

DownloadAndInstall(url) {
    global SCRIPT_DIR, TEMP_DIR
    
    SplitPath, SCRIPT_DIR, , parentDir
    
    FileRemoveDir, %TEMP_DIR%, 1
    FileCreateDir, %TEMP_DIR%
    
    zipPath := TEMP_DIR "\update.zip"
    extractPath := TEMP_DIR "\extracted"
    FileCreateDir, %extractPath%
    
    try {
        whr := ComObjCreate("WinHttp.WinHttpRequest.5.1")
        whr.Open("GET", url, true)
        whr.Send()
        whr.WaitForResponse()
        
        body := whr.ResponseBody
        pData := NumGet(ComObjValue(body) + 8 + A_PtrSize, "UPtr")
        length := NumGet(ComObjValue(body) + 8 + 2*A_PtrSize, "UInt")
        
        FileOpen(zipPath, "w").RawWrite(pData+0, length)
    } catch e {
        return false
    }
    
    if (!FileExist(zipPath)) {
        return false
    }
    
    extractCmd := "powershell -Command ""Expand-Archive -Path '" zipPath "' -DestinationPath '" extractPath "' -Force"""
    RunWait, %extractCmd%, , Hide
    
    sourcePath := extractPath "\Ultimate Macro"
    if (FileExist(sourcePath)) {
        copyCmd := "powershell -Command ""Copy-Item -Path '" sourcePath "\*' -Destination '" SCRIPT_DIR "' -Recurse -Force"""
    } else {
        copyCmd := "powershell -Command ""Copy-Item -Path '" extractPath "\*' -Destination '" SCRIPT_DIR "' -Recurse -Force"""
    }
    
    RunWait, %copyCmd%, , Hide
    
    FileRemoveDir, %TEMP_DIR%, 1
    
    return true
}

ShowError(msg) {
    MsgBox, 16, Update Error, %msg%
}

if (%0% < 2) {
    MsgBox, 16, Error, Usage: update.ahk <current_version> <script_dir>
    ExitApp
}

currentVersion = %1%
SCRIPT_DIR = %2%

result := CheckForUpdate(currentVersion)
ExitApp %result%