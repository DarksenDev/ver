===================================
        ULTIMATE MACRO
===================================

⚠️ IMPORTANT! READ BEFORE LAUNCH!

1. EXTRACT ALL FILES FROM THE ARCHIVE!
   - DO NOT run the program directly from RAR/ZIP/7z
   - Extract the archive to any folder on your computer

2. DO NOT MOVE INDIVIDUAL FILES!
   - All files must remain in the same folder
   - Do not delete the "assets" folder or its contents

3. HOW TO LAUNCH:
   - Open the folder with extracted files
   - Run "Ultimate Macro.exe"

===================================
        SYSTEM REQUIREMENTS
===================================

- Windows 7/8/10/11 (x64)
- AutoHotkey installed (V1 & V2!)
- Stable internet connection

===================================
          SOCIALS
===================================

Discord: https://discord.gg/DQnc2JDJtr
YouTube: https://www.youtube.com/@darksenn

===================================